#include <stdio.h>



int main(){
	int len = 0;
	char *s;
	printf("Input : ");
	while((*(s+len) = getchar()) != '\n') len++;
	printf("Output : ");

	for(int i = 0; i < len/2; i++){
		if(*(s+i) != *(s+len-i-1)){
			printf("False\n");
			return 0;
		}
	}

	printf("True\n");


	


	return 0;
}