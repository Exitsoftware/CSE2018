#include <stdio.h>

char *strcpy(char *s1, register const char *s2){
	register char *p = s1;
	while (*p++ = *s2++)
		;
	return s1;
}


char *strcat(char *s1, register const char *s2){
	register char *p = s1;
	while (*p)
		++p;
	while (*p++ = *s2++)
		;
	return s1;
}

int main(){
	char input1[10000];
	char input2[10000];
	scanf("%s", input1);
	
	printf("strcpy : input2 = %s\n", strcpy(input2, input1));
	printf("strcat : input1 + input2 %s\n", strcat(input1, input2));
	return 0;
}